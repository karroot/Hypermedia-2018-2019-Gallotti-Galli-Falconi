'use strict';


/**
 * Information about us
 *
 * no response value expected for this operation
 **/
exports.aboutGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Ways to contacts us
 *
 * no response value expected for this operation
 **/
exports.contactUsGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Frequently asked questions
 *
 * no response value expected for this operation
 **/
exports.fAQGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List of opened positions
 *
 * no response value expected for this operation
 **/
exports.workWithUsGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

